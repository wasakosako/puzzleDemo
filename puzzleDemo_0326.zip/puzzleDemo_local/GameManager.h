#ifndef GAMEMANAGER_H
#define GAMEMANAGER_H

#include <stdio.h>
#include <windows.h>
#include <time.h>   // 時間管理用のヘッダ

/// @brief ゲームのシーン
typedef enum {
    START,  // スタート画面
    MENU,   // メニュー画面
    INIT,   // ゲーム開始前の処理
    GAMEF1, // ゲーム画面(移動ドロップ決定)
    GAMEF2, // ゲーム画面(ドロップ移動)
    RESULT, // リザルト画面
    QUIT    // ゲーム終了
} SceneName;

//===================================================
// 関数のプロトタイプ宣言
//===================================================

void ClearConsole(void);            // コンソールをクリアする関数
void SceneProcessing(void);         // シーンごとの処理
void PrintLightLine(void);          // 横線を表示させる関数

#endif // GAMEMANAGER_H
