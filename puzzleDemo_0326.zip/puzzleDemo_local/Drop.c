#include <windows.h>
#include "Drop.h"

/// @brief ドロップの色変更
/// @param dc ドロップの構造体
void SetDropColor(Drop d) {
    // ハンドルを取得し、色を入れる変数を白で初期化
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    WORD colorAttribute = FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE;

    // ドロップの色を決定
    switch (d.color) {
        case FIRE:  colorAttribute = FOREGROUND_RED; break;
        case WATER: colorAttribute = FOREGROUND_BLUE; break;
        case GRASS: colorAttribute = FOREGROUND_GREEN; break;
        case RIGHT: colorAttribute = FOREGROUND_RED | FOREGROUND_GREEN; break; // 黄色
        case DARK:  colorAttribute = FOREGROUND_RED | FOREGROUND_BLUE; break;  // 紫
        case HEAL:  colorAttribute = FOREGROUND_GREEN | FOREGROUND_BLUE; break; // 水色
        default:    break;
    }

    // PLUSドロップなら強調（未実装）
    /*
    if (d.kind == PLUS) {
        colorAttribute |= FOREGROUND_INTENSITY;
    }*/

    // 色を適用
    SetConsoleTextAttribute(hConsole, colorAttribute);

    return;
}; 

/// @brief ドロップの色をリセット
/// @param  
void ResetDropColor(void) {
    // ハンドルを取得し、文字の色を白にセット
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);

    return;
}