#include "Board.h"
#include "GameManager.h"
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>  // MinGW用のヘッダ
#include <time.h>   // 時間管理用のヘッダ

//===================================================
// グローバル変数
//===================================================
int FPS = 10;           // 画面のリフレッシュ時間
boolean isClearConsole; // 画面をクリアするかのフラグ

/// @brief コンソールのクリア
void ClearConsole(void) {
    system("cls");  // Windows用のコマンドに変更
}

/// @brief 即時入力の取得関数（Windows）
char GetChar(void) {
    if (_kbhit()) {         // キーが押されているかをチェック
        return _getch();    // 押されたキーを取得
    }
    return '\0';            // 何も押されていなければNULLを返す
}

/// @brief シーンごとの処理関数
void SceneProcessing(void) {
    SceneName scene = START;        // シーンをスタートにセット
    char input = '\0';              // 入力結果を格納する変数
    isClearConsole = TRUE;          // 最初に1回だけ画面クリア
    clock_t prev_time = clock();    // 直前の時間を取得
    double frame_duration =
        1.0 / FPS * CLOCKS_PER_SEC; // 画面更新のための待ち時間を計算

    while (scene != QUIT) {
        clock_t current_time = clock(); // 今の時間を取得
        char copyInput = GetChar();     // とりあえずコピーに入力を取得
        if (copyInput != '\0')
            input = copyInput;          // 入力が空ならコピーを代入

        //================================================
        // 処理
        //================================================
        switch (scene) {
            case START:
                // エンターキーで決定
                if (input == '\r') {
                    scene = MENU;
                    input = '\0';
                    isClearConsole = TRUE;
                }

                break;
            case MENU:
                // エンターキーで決定
                if (input == '\r') {
                    scene = INIT;
                    input = '\0';
                    isClearConsole = TRUE;
                }

                break;
            case INIT:
                scene = GAMEF1;
                isClearConsole = TRUE;

                // 盤面リセット
                InitBoard(&board_drop);
                InitBoardforJudge(&board_judge);

                // スコア集計表をリセット
                for (int i = 0; i < ColorNum; i++)
                    for (int j = 0; j < BOARD_WIDTH*BOARD_HEIGHT-3+1; j++)
                        for (int k = 0; k < KindNum; k++)
                            cntCombo[i][j][k] = 0;

                break;
            case GAMEF1:
                // エンターキーで決定
                if (input == '\r') {
                    scene = GAMEF2;
                    input = '\0';
                    isClearConsole = TRUE;
                }

                // wadxでドロップ切り替え&入力をリセット
                switch (input) {
                    case 'w': SwitchTargetDrop( 0, -1); input = '\0'; isClearConsole = TRUE; break;
                    case 'a': SwitchTargetDrop(-1,  0); input = '\0'; isClearConsole = TRUE; break;
                    case 'd': SwitchTargetDrop( 1,  0); input = '\0'; isClearConsole = TRUE; break;
                    case 'x': SwitchTargetDrop( 0,  1); input = '\0'; isClearConsole = TRUE; break;
                }

                break;
            case GAMEF2:
                // エンターキーで操作をやめる
                if (input == '\r') {
                    scene = RESULT;
                    input = '\0';
                    isClearConsole = TRUE;

                    // リザルト画面に行く前にスコアを計算
                    ScoreCal(&board_drop, &board_judge);
                }

                // qweasdzxcでドロップ切り替え&入力をリセット
                switch (input) {
                    case 'q': MoveTargetDrop(&board_drop, -1, -1); input = '\0'; isClearConsole = TRUE; break;
                    case 'w': MoveTargetDrop(&board_drop,  0, -1); input = '\0'; isClearConsole = TRUE; break;
                    case 'e': MoveTargetDrop(&board_drop,  1, -1); input = '\0'; isClearConsole = TRUE; break;
                    case 'a': MoveTargetDrop(&board_drop, -1,  0); input = '\0'; isClearConsole = TRUE; break;
                    case 'd': MoveTargetDrop(&board_drop,  1,  0); input = '\0'; isClearConsole = TRUE; break;
                    case 'z': MoveTargetDrop(&board_drop, -1,  1); input = '\0'; isClearConsole = TRUE; break;
                    case 'x': MoveTargetDrop(&board_drop,  0,  1); input = '\0'; isClearConsole = TRUE; break;
                    case 'c': MoveTargetDrop(&board_drop,  1,  1); input = '\0'; isClearConsole = TRUE; break;
                }

                break;
            case RESULT:
                // qならシーンを終了に、rならメニューにする
                if (input == 'q') {
                    scene = QUIT;
                    input = '\0';
                    isClearConsole = TRUE;
                }
                else if (input == 'r') {
                    scene = MENU;
                    input = '\0';
                    isClearConsole = TRUE;
                }

                break;
            default:
                break;
        }

        //================================================
        // 画面更新判定
        //================================================

        // 判定１
        // 今の時間が、直前の時間＋FPSの待ち時間以上になっているか
        if ((double)(current_time - prev_time) >= frame_duration) {
            prev_time = current_time;   // 時間を更新
        }
        else continue;

        // 判定２
        // 画面更新フラグが立っているか
        if (isClearConsole) {
            ClearConsole();         // コンソールをクリア
            isClearConsole = FALSE; // フラグをリセット
        }
        else continue;

        printf("現在のシーン: ");

        //================================================
        // 描画
        //================================================
        switch (scene) {
            case START:
                printf("スタート画面\n");
                printf("Enter：メニューへ");

                break;
            case MENU:
                printf("メニュー画面\n");
                printf("Enter：決定\n\n");
                printf("▶ノーマル");

                break;
            case GAMEF1:
                printf("ゲーム実行中\n");
                printf("動かすドロップを決めるターンです。\n\n");
                PrintLightLine();
                printf("操作方法：\n");
                printf("　　　　ｗ\n");
                printf("　　　Ａ　Ｄ\n");
                printf("　　　　Ｘ\n\n");
                printf("Enter：ドロップ決定\n\n\n");
                PrintLightLine();
                printf("\n\n");

                // 盤面表示
                DisplayBoard(&board_drop);

                break;
            case GAMEF2:
                printf("ゲーム実行中\n");
                printf("ドロップを動かすターンです。\n\n");
                PrintLightLine();
                printf("操作方法：\n");
                printf("　　　ＱｗＥ\n");
                printf("　　　Ａ　Ｄ\n");
                printf("　　　ＺＸＣ\n\n");
                printf("Enter：操作をやめる\n\n\n");
                PrintLightLine();
                printf("\n\n");

                // 盤面表示
                DisplayBoard(&board_drop);

                break;
            case RESULT:
                printf("リザルト画面\n\n");
                PrintLightLine();
                printf("最終盤面\n");

                // 盤面表示
                DisplayBoard(&board_drop);

                printf("\n");
                PrintLightLine();
                printf("\nコンボまとめ\n");
                int sum = 0;
                for (int i = 0; i < KindNum; i++) sum += cntCombo[FIRE][0][i];
                printf("火ドロップ　：%dコンボ, スコア：%d\n"  , sum, sum*100);
                sum = 0;
                for (int i = 0; i < KindNum; i++) sum += cntCombo[WATER][0][i];
                printf("水ドロップ　：%dコンボ, スコア：%d\n"  , sum, sum*100);
                sum = 0;
                for (int i = 0; i < KindNum; i++) sum += cntCombo[GRASS][0][i];
                printf("草ドロップ　：%dコンボ, スコア：%d\n"  , sum, sum*100);
                sum = 0;
                for (int i = 0; i < KindNum; i++) sum += cntCombo[RIGHT][0][i];
                printf("光ドロップ　：%dコンボ, スコア：%d\n"  , sum, sum*100);
                sum = 0;
                for (int i = 0; i < KindNum; i++) sum += cntCombo[DARK][0][i];
                printf("闇ドロップ　：%dコンボ, スコア：%d\n"  , sum, sum*100);
                sum = 0;
                for (int i = 0; i < KindNum; i++) sum += cntCombo[HEAL][0][i];
                printf("回復ドロップ：%dコンボ, 回復力：%d\n\n", sum, sum*100);
                PrintLightLine();
                printf("\nゲーム終了：Q\n");
                printf("\nもう一回　：R\n");

                break;
            default:
                break;
        }
    }

    printf("ゲームを終了しました。\n");
}

// 盤面の横線表示
void PrintLightLine(void) {
    printf("========================================================\n");
}