#include "GameManager.h"

// メイン関数
int main(void) {
    SetConsoleOutputCP(65001);  // コンソールの出力エンコーディングを UTF-8 に変更
    SceneProcessing();
    return 0;
}
