#ifndef BOARD_H
#define BOARD_H

#include <stdio.h>
#include "GameManager.h"
#include "Drop.h"

#define BOARD_WIDTH 6   // ボードの横幅
#define BOARD_HEIGHT 5  // ボードの縦幅

/// @brief 盤面の構造体
typedef struct {
    Drop drops[BOARD_HEIGHT][BOARD_WIDTH];  // ボード上のドロップ
} Board;

//===================================================
// グローバル変数
//===================================================

extern Board board_drop;    // 盤面（ドロップ）
extern Board board_judge;   // 盤面（判定）
extern int targetX;         // 持ったドロップのX座標
extern int targetY;         // 持ったドロップのY座標

// 「どの色のドロップが」「X個繋がっているコンボがいくつあって」「どの種類のドロップをいくつ含むか」
// 縦横を3つ以上揃えると1コンボとする
extern int cntCombo[ColorNum][BOARD_WIDTH*BOARD_HEIGHT-3+1][KindNum];

//===================================================
// 関数のプロトタイプ宣言
//===================================================

void InitBoard(Board *board);                                               // ボードの初期化
void InitBoardforJudge(Board *board);                                       // ボードの初期化(判定用盤面)
void DisplayBoard(Board *board);                                            // ボードの表示
void SetDrop(Board *board, int X, int Y, DropKind type, DropColor color);   // ドロップをボードに配置
void SwitchTargetDrop(int X, int Y);                                        // 持つドロップの切り替え
void MoveTargetDrop(Board *board, int X, int Y);                            // 持ったドロップの移動
void ScoreCal(Board *boardD, Board *boardJ);                                // 盤面のスコア計算                                               // 盤面のスコア判定

#endif // BOARD_H