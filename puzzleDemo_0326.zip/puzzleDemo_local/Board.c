#include "Board.h"
#include <stdio.h>
#include <stdlib.h> // ランダム関数使用のため使用
#include <time.h>   // 現在時刻取得のため使用

//===================================================
// グローバル変数
//===================================================

Board board_drop;   // 盤面（ドロップ）
Board board_judge;  // 盤面（判定）
int targetX = 0;    // 持ったドロップのX座標
int targetY = 0;    // 持ったドロップのY座標

// 「どの色のドロップが」「X個繋がっているコンボがいくつあって」「どの種類のドロップをいくつ含むか」
// 縦横を3つ以上揃えると1コンボとする
int cntCombo[ColorNum][BOARD_WIDTH*BOARD_HEIGHT-3+1][KindNum];

//===================================================
// 関数
//===================================================

// 補助関数のプロトタイプ宣言
boolean Drop_isCombo(Board boardD, int X, int Y);
void Drop_calScore(Board *boardJ, int X, int Y, DropColor color, int *cnt);

/// @brief ドロップ用盤面の初期化（ランダム）
/// @param board 盤面の先頭ポインタ
void InitBoard(Board *board) {
    // 現在時刻を参照してrandを初期化
    srand((unsigned int) time(NULL));

    for (int y = 0; y < BOARD_HEIGHT; y++)
    {
        for (int x = 0; x < BOARD_WIDTH; x++)
        {
            // ドロップを生成
            Drop d;
            d.color = rand() % ColorNum;
            d.kind = rand() % KindNum;

            // ランダムにドロップをセット
            board->drops[y][x] = d;
        }
    }

    return;
};

/// @brief 判定用盤面の初期化（ランダム）
/// @param board 盤面の先頭ポインタ
void InitBoardforJudge(Board *board) {
    for (int y = 0; y < BOARD_HEIGHT; y++)
    {
        for (int x = 0; x < BOARD_WIDTH; x++)
        {
            // コンボしたドロップなし
            board->drops[y][x].color = NONE;
            board->drops[y][x].kind = NORMAL;
        }
    }

    return;
};

/// @brief 盤面表示
/// @param board 表示させる盤面
void DisplayBoard(Board *board) {

    PrintLightLine();

    for (int y = 0; y < BOARD_HEIGHT; y++)
    {
        // 横をちょっと開ける
        printf("　　|");

        for (int x = 0; x < BOARD_WIDTH; x++)
        {
            // 横をちょっと開ける
            printf("　");

            // ドロップの色を変更
            SetDropColor(board->drops[y][x]);

            // ドロップ表示
            if (x == targetX && y == targetY) printf("○");
            else printf("●");
        }

        // ドロップの色を元に戻す
        ResetDropColor();

        // 横をちょっと開ける
        printf("　|");

        // 次の段へ
        printf("\n");
    }

    return;
};

//void SetDrop(Board *board, int x, int y, DropKind type, DropColor color){return;};

/// @brief 持つドロップの切り替え
/// @param X X座標の移動量
/// @param Y Y座標の移動量
void SwitchTargetDrop(int X, int Y) {
    if (targetX + X <  BOARD_WIDTH &&
        targetX + X >= 0)
        targetX += X;

    if (targetY + Y <  BOARD_HEIGHT &&
        targetY + Y >= 0)
        targetY += Y;

    return;
}

/// @brief 持ったドロップの移動
/// @param board 移動させる盤面
/// @param X X座標の移動量
/// @param Y Y座標の移動量
void MoveTargetDrop(Board *board, int X, int Y) {
    // 移動先が盤面外なら何もせず返す（X）
    if (targetX + X >= BOARD_WIDTH ||
        targetX + X <  0)
        return;
    // 移動先が盤面外なら何もせず返す（Y）
    if (targetY + Y >= BOARD_HEIGHT ||
        targetY + Y <  0)
        return;
    
    // 一時保存用ドロップ
    Drop copyD;
    
    // 移動先のドロップと入れ替え
    copyD = board->drops[targetY+Y][targetX+X];
    board->drops[targetY+Y][targetX+X] = board->drops[targetY][targetX];
    board->drops[targetY][targetX] = copyD;

    // 持つドロップも変える
    targetX += X;
    targetY += Y;

    return;
};

/// @brief 盤面のスコア計算
/// @param boardD ドロップ用盤面
/// @param boardJ 判定用用盤面
void ScoreCal(Board *boardD, Board *boardJ) {
    // 判定用盤面を作成
    for (int y = 0; y < BOARD_HEIGHT; y++)
    {
        for (int x = 0; x < BOARD_WIDTH; x++)
        {
            if (Drop_isCombo(*boardD, x, y))
            boardJ->drops[y][x] = boardD->drops[y][x];
        }
    }

    // 判定用盤面からスコアを計算し、配列に格納
    for (int y = 0; y < BOARD_HEIGHT; y++)
    {
        for (int x = 0; x < BOARD_WIDTH; x++)
        {
            // ドロップの色を保存
            int dColor = boardJ->drops[y][x].color;
            // カウントを用意
            int cnt[KindNum] = {0};

            // 判定用盤面からドロップ情報を計算する補助関数を実行
            Drop_calScore(boardJ, x, y, dColor, cnt);

            // 計算したドロップ情報を格納
            int cntSum = 0;
            for (int i = 0; i < KindNum; i++) cntSum += cnt[i];
            for (int i = 0; i < KindNum; i++) cntCombo[dColor][cntSum-3][i] += 1;
        }
    }
};

/// @brief ドロップ判定用の補助関数
/// @param boardD 対象のドロップ用盤面（写し）
/// @param boardJ 対象の判定用盤面（ポインタ）
/// @param X 対象ドロップのX座標
/// @param Y 対象ドロップのY座標
/// @return そのドロップはコンボしているかどうか
boolean Drop_isCombo(Board boardD, int X, int Y) {
    // 1,自分自身が盤面外であれば、揃っていない
    if (X < 0 || X >= BOARD_WIDTH || Y < 0 || Y >= BOARD_HEIGHT) return FALSE;

    // 2,自分自身がドロップ無しであれば、揃っていない
    if (boardD.drops[Y][X].color == NONE) return FALSE;

    // カウントを用意
    // 自分は自分自身と繋がっているので、カウントは1から
    int cnt = 1;

    // 右方向に走査
    for (int i = X; i < BOARD_WIDTH; i++)
        if (boardD.drops[Y][X].color == boardD.drops[Y][i].color) ++cnt;
        else break;
    // 左方向に走査
    for (int i = X; i >= 0; i--)
        if (boardD.drops[Y][X].color == boardD.drops[Y][i].color) ++cnt;
        else break;
    
    // 横方向に3つ以上繋がっていればコンボしたとみなす
    if (cnt >= 3) return TRUE;
    else cnt = 1;

    // 下方向に走査
    for (int i = Y; i < BOARD_HEIGHT; i++)
        if (boardD.drops[Y][X].color == boardD.drops[i][Y].color) ++cnt;
        else break;
    // 上方向に走査
    for (int i = Y; i >= 0; i--)
        if (boardD.drops[Y][X].color == boardD.drops[i][X].color) ++cnt;
        else break;
    
    // 縦方向に3つ以上繋がっていればコンボしたとみなす
    if (cnt >= 3) return TRUE;
    else return FALSE;
};

/// @brief 判定用盤面からドロップ情報を計算する補助関数
/// @param boardJ 判定用盤面
/// @param color 自分のドロップの色
/// @param X X座標
/// @param Y Y座標
void Drop_calScore(Board *boardJ, int X, int Y, DropColor color, int *cnt) {
    // 1,自分自身が盤面外であれば、何もせず返す
    if (X < 0 || X >= BOARD_WIDTH || Y < 0 || Y >= BOARD_HEIGHT) return;

    // 2,自分自身がドロップ無しであれば、何もせず返す
    if (boardJ->drops[Y][X].color == NONE) return;

    // 方向配列 (上下左右)
    int dx[4] = {0, 1, 0, -1};
    int dy[4] = {-1, 0, 1, 0};

    // 3,上下左右の4方向を操作し、自分と同じ属性のドロップか調べる
    for (int i = 0; i < (int)(sizeof(dx)/sizeof(dx[0])); i++)
    {
        // 同じ色だったら
        if (color == boardJ->drops[Y+dy[i]][X+dx[i]].color) {
            ++cnt[boardJ->drops[Y][X].kind];                // カウントアップ
            int c = boardJ->drops[Y][X].color;              // 自分の色を一時保存
            boardJ->drops[Y][X].color = NONE;               // 「判定済み」とし、ドロップなしにする
            Drop_calScore(boardJ, X+dx[i], Y+dy[i], c, cnt);// 自分自身を実行
        }
    }

    return;
}