#ifndef DROP_H
#define DROP_H

#include <stdio.h>

/// @brief ドロップの属性
typedef enum {
    FIRE,    // 火
    WATER,   // 水
    GRASS,   // 草
    RIGHT,   // 光
    DARK,    // 闇
    HEAL,    // 回復
    ColorNum,// ドロップの属性数
    NONE     // ドロップなし
} DropColor;

/// @brief ドロップの種類
typedef enum {
    NORMAL, // ノーマルドロップ
    PLUS,   // 強化ドロップ
    KindNum // ドロップの種類数
} DropKind;

/// @brief ドロップの属性と種類をまとめた構造体
typedef struct {
    DropColor color;
    DropKind kind;
} Drop;

//===================================================
// 関数のプロトタイプ宣言
//===================================================

void SetDropColor(Drop d);  // ドロップの色を変える関数
void ResetDropColor(void);  // ドロップの色を戻す関数

#endif // DROP_H